/**
 * Created by stameying on 1/20/16.
 */
public class weightedWord {
    String word;
    int frequency;
    public weightedWord(String word, int frequency){
        this.word = word;
        this.frequency = frequency;
    }
}
